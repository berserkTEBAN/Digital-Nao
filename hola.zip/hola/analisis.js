document.addEventListener("DOMContentLoaded", function () {
    const modificarMargen = (id, valor) => {
        const elemento = document.getElementById(id);
        if (elemento) {
            elemento.style.marginTop = valor;
        }
    }

    const actualizarValorYPosicion = (clave, claseTexto, idImagen, idTexto) => {
        const valor = localStorage.getItem(clave);
        const contenedorTexto = document.querySelector(`.${claseTexto}-text`);
        const contenedorValor = document.querySelector(`.${claseTexto}-value`);

        if (valor) {
            contenedorValor.innerHTML = '$' + valor;
            contenedorTexto.style.top = '0';
            contenedorTexto.style.bottom = '';
            modificarMargen(idImagen, '10px');
        } else {
            document.getElementById(idTexto).classList.remove(`${claseTexto}-text`);
            contenedorTexto.style.top = '';
            contenedorTexto.style.bottom = '0';
        }
    }

    actualizarValorYPosicion('ingresos', 'ingresos', 'ingresosImagen', 'txtIngresos');
    actualizarValorYPosicion('gastos', 'gastos', 'gastosImagen', 'txtGastos');
    actualizarValorYPosicion('ahorros', 'ahorros', 'ahorrosImagen', 'txtAhorro');
    actualizarValorYPosicion('deudas', 'deudas', 'deudasImagen', 'txtDeudas');
    const ingresosValue = localStorage.getItem('ingresos');
    const gastosValue = localStorage.getItem('gastos');
    const ahorrosValue = localStorage.getItem('ahorros');
    const deudasValue = localStorage.getItem('deudas');

    if (ingresosValue && gastosValue) {
        document.getElementById('calcularValores').style.display = 'inline-flex';
    } else {
        document.getElementById('calcularValores').style.display = 'none';
    }
});
