var urlParams = new URLSearchParams(window.location.search);
var r = urlParams.get('r');
// Objeto que contiene la información de cada sección
var sectionInfo = {
    "ingresos": {
        "title": "ingresos",
        "image": "icons/ingresos.svg",
        "helperText": "Coloca el dinero que sueles recibir cada mes.",
        /*"examples": [
            { "example": "Pensiones y jubilaciones", "text": "Descripción de pensiones y jubilaciones" },
            { "example": "Remesas", "text": "Descripción de remesas" },
            { "example": "Por alquiler de bienes", "text": "Descripción de alquiler de bienes" },
            { "example": "Por rentas", "text": "Descripción de rentas" },
            { "example": "Inversiones, utilidades", "text": "Descripción de inversiones y utilidades" },
            { "example": "Ayudas de gobierno", "text": "Descripción de ayudas de gobierno" }
        ]*/
    },
    "gastos": {
        "title": "gastos",
        "image": "icons/gastos.svg",
        "helperText": "Coloca el dinero que destinas para cubrir tus necesidades cotidianas cada mes.",
        "examples": [
            { "example": "Agua", "text": "Descripción de agua" },
            { "example": "Luz", "text": "Descripción de luz" },
            { "example": "Internet", "text": "Descripción de internet" },
            { "example": "Gas", "text": "Descripción de gas" },
            { "example": "Renta y mantenimiento", "text": "Descripción de renta y mantenimiento" },
            { "example": "Seguros", "text": "Descripción de seguros" },
            { "example": "Educacion", "text": "Descripción de educación" },
            { "example": "Salud", "text": "Descripción de salud" },
            { "example": "Transporte", "text": "Descripción de transporte" },
            { "example": "Entretenimiento", "text": "Descripción de entretenimiento" },
            { "example": "Alimentacion", "text": "Descripción de alimentación" }
        ]
    },
    "deudas": {
        "title": "deudas",
        "image": "icons/deudas.svg",
        "helperText": "Coloca el dinero que destinas para pagar créditos o préstamos durante el mes.",
        "examples": [
            { "example": "Tarjeta de crédito", "text": "Descripción de tarjeta de crédito" },
            { "example": "Crédito hipotecario", "text": "Descripción de crédito hipotecario" },
            { "example": "Préstamo personal", "text": "Descripción de préstamo personal" },
            { "example": "Préstamo de nómina", "text": "Descripción de préstamo de nómina" },
            { "example": "Crédito de auto", "text": "Descripción de crédito de auto" },
            { "example": "Crédito de muebles", "text": "Descripción de crédito de muebles" },
            { "example": "Créditos de amigos, tandas, cajas", "text": "Descripción de créditos de amigos, tandas, cajas" },
            { "example": "Creditos educativos", "text": "Descripción de créditos educativos" },
            { "example": "Creditos de servicios atrasados", "text": "Descripción de créditos de servicios atrasados" },
            { "example": "Renta atrasadas", "text": "Descripción de renta atrasadas" },
            { "example": "Créditos o tarjetas departamentales", "text": "Descripción de créditos o tarjetas departamentales" }
        ]
    },
    "ahorros": {
        "title": "ahorros",
        "image": "icons/ahorros.svg",
        "helperText": "Coloca el dinero que guardas durante el mes.",
        "examples": [
            { "example": "Cuentas de ahorro", "text": "Descripción de cuentas de ahorro" },
            { "example": "Inversiones", "text": "Descripción de inversiones" },
            { "example": "Efectivo", "text": "Descripción de efectivo" }
        ]
    }
};
function showExampleModal(example, text) {
    document.getElementById("modalBody").innerHTML = '<p><strong>' + example + '.</strong> ' + text + '</p>';
}
function initSection(section) {
    document.getElementById("sectionImageContainer").innerHTML = '<img src="' + section.image + '" class="container-imagen" width="100px" height="100px" alt="Icono de ' + section.title + '" />';
    document.getElementById("helper-text").textContent = section.helperText;
    var examples = section.examples;
    var examplesHTML = '<div class="text-center">Ejemplos de ' + section.title + ':</div><div class="income-types">';

    if (examples.length > 6) {
        var halfLength = Math.ceil(examples.length / 2);
        var examples1 = examples.slice(0, halfLength);
        var examples2 = examples.slice(halfLength);

        examplesHTML += '<div class="examples-container two-columns"><ul><div class="row"><div class="col">' + examples1.map(example => "<li data-bs-toggle='modal' data-bs-target='#opcionesModal' onclick='showExampleModal(\"" + example.example + "\", \"" + example.text + "\")'>" + example.example + "</li>").join("") + '</div><div class="col">' + examples2.map(example => "<li data-bs-toggle='modal' data-bs-target='#opcionesModal' onclick='showExampleModal(\"" + example.example + "\", \"" + example.text + "\")'>" + example.example + "</li>").join("") + '</div></div></ul></div>';
    } else {
        examplesHTML += '<ul>' + examples.map(example => "<li data-bs-toggle='modal' data-bs-target='#opcionesModal' onclick='showExampleModal(\"" + example.example + "\", \"" + example.text + "\")'>" + example.example + "</li>").join("") + '</ul>';
    }

    examplesHTML += '</div>';
    document.getElementById("examples").innerHTML = examplesHTML;
}





function obtenerTotalIngresos() {
    var totalIngresos = 0;

    // Iterar sobre todas las claves del localStorage
    for (var i = 0; i < localStorage.length; i++) {
        var clave = localStorage.key(i);

        // Verificar si la clave corresponde a un valor de r
        if (clave.startsWith('ingresos_')) {
            // Obtener el valor almacenado para esta clave y sumarlo al total
            var valor = parseFloat(localStorage.getItem(clave)) || 0;
            totalIngresos += valor;
        }
    }

    return totalIngresos;
}




function guardarDatos() {
    try {
        var urlParams = new URLSearchParams(window.location.search);
        var r = urlParams.get('r');
        var incomeType = urlParams.get('tipo');

        if (!r) {
            throw new Error("No se encontró el parámetro 'r' en la URL.");
        }

        if (!incomeType) {
            throw new Error("No se encontró el parámetro 'tipo' en la URL.");
        }

        // Obtener el valor del campo de ingresos
        var ingresosInput = document.getElementById("txtIngresos").value.trim();
        
        if (!ingresosInput) {
            throw new Error("Ingrese un valor para los ingresos.");
        }

        var ingresos = parseFloat(ingresosInput);

        if (isNaN(ingresos)) {
            throw new Error("El valor de ingresos no es válido.");
        }
        
        // Obtener el valor actual de ingresos para este r
        var ingresosAnteriores = parseFloat(localStorage.getItem(r)) || 0;
        var ingresosTipoAnterior = parseFloat(localStorage.getItem(r + '_' + incomeType)) || 0;

        // Calcular el nuevo total de ingresos sumando el valor actual con los ingresos ingresados
        var nuevoTotalIngresos = ingresosAnteriores - ingresosTipoAnterior + ingresos;

        // Almacenar el nuevo total de ingresos en el almacenamiento local
        localStorage.setItem(r, nuevoTotalIngresos);

        // Almacenar el nuevo valor de ingresos en el almacenamiento local, utilizando r y incomeType
        localStorage.setItem(r + '_' + incomeType, ingresos);

        // Imprimir los valores de incomeType y r
        console.log("Tipo de ingreso:", incomeType);
        console.log("Valor de r:", r);
        
        // Obtener la suma total de todos los ingresos
        var totalIngresos = obtenerTotalIngresos();
        console.log("Suma total de ingresos:", totalIngresos);

        // Limpiar el formulario
        document.getElementById("txtIngresos").value = "";

        // Redireccionar al usuario según el valor de 'r'
        switch (r) {
            case 'ingresos':
                window.location.href = 'detalle.html';
                break;
            case 'gastos':
                window.location.href = 'detalle2.2.html';
                break;
            case 'deudas':
            case 'ahorros':
                window.location.href = 'analisis.html';
                break;
            default:
                window.location.href = 'analisis.html';
        }
    } catch (error) {
        // Manejo de errores: Mostrar el mensaje de error
        console.error("Error al guardar datos:", error.message);
        // Puedes agregar aquí código para mostrar un mensaje de error al usuario si lo deseas
    }
}


function cargarValores() {
    var urlParams = new URLSearchParams(window.location.search);
    var r = urlParams.get('r');
    var incomeType = urlParams.get('tipo');
    var ingresos = localStorage.getItem(r + '_' + incomeType);
    document.getElementById("txtIngresos").value = ingresos;
}

cargarValores(); // Llama a cargarValores al cargar la página


switch (r) {
    case 'ingresos':
        initSection(sectionInfo.ingresos);
        break;
    case 'gastos':
        initSection(sectionInfo.gastos);
        break;
    case 'deudas':
        initSection(sectionInfo.deudas);
        break;
    case 'ahorros':
        initSection(sectionInfo.ahorros);
        break;
    default:
}


// 
