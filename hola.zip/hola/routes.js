document.getElementById("botonSiguiente").addEventListener("click", function() {
    window.location.href = "detalle2.2.html";
});


document.getElementById("botonSiguiente2").addEventListener("click", function() {
    window.location.href = "detalle3.html";
});




function redirectToInputs(incomeType, r) {
    window.location.href = 'inputs.html?r=' + encodeURIComponent(r) + '&tipo=' + encodeURIComponent(incomeType);
}

